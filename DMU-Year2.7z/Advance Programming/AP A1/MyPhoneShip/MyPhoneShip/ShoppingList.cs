﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneShop
{
    public class ShoppingList
    {
        private string shoppingList = "Shopping List";
        private List<MobilePhone> phoneInList;
        private int currentlyViewedPhone = 0;
        

        public ShoppingList()
        {
            phoneInList = new List<MobilePhone>();
        }

        public List<MobilePhone> GetPhoneInList => phoneInList;

        public int NumberOfPhones
        {
            get { return phoneInList.Count; }
        }

        public int CurrentlyViewedPhone
        {
            get { return currentlyViewedPhone; }
        }

        public string DescribeShoppingList()
        {
            return shoppingList;
        }

        //method for add phone
        public void AddPhone(MobilePhone mobilePhone)
        {
            phoneInList.Add(mobilePhone);
        }

        public void RemovePhoneAt(int index)
        {
            if (index < phoneInList.Count)
            {
                phoneInList.RemoveAt(index);
                // make sure currentlyViewedPhone is either zero or pointing at an existing phone
                LegalisePhoneCurentlyDisplayed();
            }
        }

        private void LegalisePhoneCurentlyDisplayed()
        {
            if (currentlyViewedPhone > (phoneInList.Count - 1))
            {
                currentlyViewedPhone = phoneInList.Count - 1;     // not this will be -1 if stock is zero

                if (currentlyViewedPhone < 0)
                {
                    currentlyViewedPhone = 0;  // make sure its legal or zero....
                }
            }
        }
    }
}
