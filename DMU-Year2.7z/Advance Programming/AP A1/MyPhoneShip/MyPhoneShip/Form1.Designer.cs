﻿namespace MyPhoneShop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblShopName = new System.Windows.Forms.Label();
            this.txtShowPhoneInfor = new System.Windows.Forms.TextBox();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.lblCurrentPhone = new System.Windows.Forms.Label();
            this.btnShoppingList = new System.Windows.Forms.Button();
            this.pictureForPhone = new System.Windows.Forms.PictureBox();
            this.pictureForSystem = new System.Windows.Forms.PictureBox();
            this.pictureForShopName = new System.Windows.Forms.PictureBox();
            this.lblAdd = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureForPhone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureForSystem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureForShopName)).BeginInit();
            this.SuspendLayout();
            // 
            // lblShopName
            // 
            this.lblShopName.AutoSize = true;
            this.lblShopName.Location = new System.Drawing.Point(186, 9);
            this.lblShopName.Name = "lblShopName";
            this.lblShopName.Size = new System.Drawing.Size(41, 12);
            this.lblShopName.TabIndex = 0;
            this.lblShopName.Text = "label1";
            // 
            // txtShowPhoneInfor
            // 
            this.txtShowPhoneInfor.Location = new System.Drawing.Point(228, 126);
            this.txtShowPhoneInfor.Multiline = true;
            this.txtShowPhoneInfor.Name = "txtShowPhoneInfor";
            this.txtShowPhoneInfor.Size = new System.Drawing.Size(162, 199);
            this.txtShowPhoneInfor.TabIndex = 1;
            this.txtShowPhoneInfor.TextChanged += new System.EventHandler(this.txtShowPhoneInfor_TextChanged);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(228, 331);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(75, 21);
            this.btnPrevious.TabIndex = 2;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(315, 331);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 21);
            this.btnNext.TabIndex = 4;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblCurrentPhone
            // 
            this.lblCurrentPhone.AutoSize = true;
            this.lblCurrentPhone.Location = new System.Drawing.Point(226, 98);
            this.lblCurrentPhone.Name = "lblCurrentPhone";
            this.lblCurrentPhone.Size = new System.Drawing.Size(41, 12);
            this.lblCurrentPhone.TabIndex = 7;
            this.lblCurrentPhone.Text = "label1";
            // 
            // btnShoppingList
            // 
            this.btnShoppingList.Location = new System.Drawing.Point(288, 381);
            this.btnShoppingList.Name = "btnShoppingList";
            this.btnShoppingList.Size = new System.Drawing.Size(102, 23);
            this.btnShoppingList.TabIndex = 9;
            this.btnShoppingList.Text = "Shopping List";
            this.btnShoppingList.UseVisualStyleBackColor = true;
            this.btnShoppingList.Click += new System.EventHandler(this.btnShoppingList_Click);
            // 
            // pictureForPhone
            // 
            this.pictureForPhone.Location = new System.Drawing.Point(12, 98);
            this.pictureForPhone.Name = "pictureForPhone";
            this.pictureForPhone.Size = new System.Drawing.Size(195, 254);
            this.pictureForPhone.TabIndex = 10;
            this.pictureForPhone.TabStop = false;
            // 
            // pictureForSystem
            // 
            this.pictureForSystem.Location = new System.Drawing.Point(12, 42);
            this.pictureForSystem.Name = "pictureForSystem";
            this.pictureForSystem.Size = new System.Drawing.Size(195, 50);
            this.pictureForSystem.TabIndex = 11;
            this.pictureForSystem.TabStop = false;
            // 
            // pictureForShopName
            // 
            this.pictureForShopName.Location = new System.Drawing.Point(288, 12);
            this.pictureForShopName.Name = "pictureForShopName";
            this.pictureForShopName.Size = new System.Drawing.Size(102, 57);
            this.pictureForShopName.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureForShopName.TabIndex = 12;
            this.pictureForShopName.TabStop = false;
            this.pictureForShopName.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblAdd
            // 
            this.lblAdd.AutoSize = true;
            this.lblAdd.Location = new System.Drawing.Point(12, 366);
            this.lblAdd.Name = "lblAdd";
            this.lblAdd.Size = new System.Drawing.Size(221, 12);
            this.lblAdd.TabIndex = 13;
            this.lblAdd.Text = "Click here to add to shopping list: ";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(12, 381);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 14;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(12, 4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 416);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblAdd);
            this.Controls.Add(this.pictureForShopName);
            this.Controls.Add(this.pictureForSystem);
            this.Controls.Add(this.pictureForPhone);
            this.Controls.Add(this.btnShoppingList);
            this.Controls.Add(this.lblCurrentPhone);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.txtShowPhoneInfor);
            this.Controls.Add(this.lblShopName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureForPhone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureForSystem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureForShopName)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblShopName;
        private System.Windows.Forms.TextBox txtShowPhoneInfor;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label lblCurrentPhone;
        private System.Windows.Forms.Button btnShoppingList;
        private System.Windows.Forms.PictureBox pictureForPhone;
        private System.Windows.Forms.PictureBox pictureForSystem;
        private System.Windows.Forms.PictureBox pictureForShopName;
        private System.Windows.Forms.Label lblAdd;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnExit;
    }
}

