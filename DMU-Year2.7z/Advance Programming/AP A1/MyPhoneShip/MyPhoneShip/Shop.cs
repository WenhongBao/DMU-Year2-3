﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneShop
{
    public class Shop
    {
        private string shopName="Storm Shop";
        private List<MobilePhone> phoneStock;
        private int currentlyViewedPhone = 0;

        public Shop()
        {
            phoneStock = new List<MobilePhone>();
        }

        public int CurrentlyViewedPhone
        {
            get { return currentlyViewedPhone; }
        }

        public List<MobilePhone> GetPhoneStock => phoneStock;

        public int NumberOfPhones
        {
            get { return phoneStock.Count; }
        }

        public string DescribeCurrentPhone()
        {
            string description;

            //create description if there have phone
            if (phoneStock.Count > 0)
            {
                description = phoneStock[currentlyViewedPhone].Description();
            }
            //if not
            else
            {
                description = "No phone in stock";
            }
            return description;
        }


        public string DescribeShopName()
        {
            return shopName;
        }

        //method for add phone 
        public void AddPhone(MobilePhone mobilePhone)
        {
            phoneStock.Add(mobilePhone);
        }

        //method for remove phone 
        public void RemovePhoneAt(int index)
        {
            if (index < phoneStock.Count)
            {
                phoneStock.RemoveAt(index);
                // make sure currentlyViewedPhone is either zero or pointing at an existing phone
                LegalisePhoneCurentlyDisplayed();
            }
        }

        private void LegalisePhoneCurentlyDisplayed()
        {
            if (currentlyViewedPhone > (phoneStock.Count - 1))
            {
                currentlyViewedPhone = phoneStock.Count - 1;     // not this will be -1 if stock is zero

                if (currentlyViewedPhone < 0)
                {
                    currentlyViewedPhone = 0;  // make sure its legal or zero....
                }
            }
        }

        public bool IsPreviousPhone()
        {
            if (currentlyViewedPhone > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsNextPhone()
        {
            if (currentlyViewedPhone < phoneStock.Count - 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void StepToPreviousPhone()
        {
            if (IsPreviousPhone())
            {
                currentlyViewedPhone--;
            }
        }

        public void StepToNextPhone()
        {
            if (IsNextPhone())
            {
                currentlyViewedPhone++;
            }
        }
    }
}
