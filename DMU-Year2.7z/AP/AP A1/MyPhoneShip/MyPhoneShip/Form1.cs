﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPhoneShop
{
    public partial class Form1 : Form
    {
        // a shop contains the list of phone and a current index
        Shop shop;
        //a shopping list contains the list of phone in shopping car and a current index
        ShoppingList shoppingList;
        //create a list to store phone image
        ImageList ImageListForPhone;
        //create a list to store operating system image
        ImageList ImageListForSystem;
        //create a list to store phone image which in shopping car
        ImageList ImageInShoppingList;
        //create a counter
        int CountForImageInShoppingList = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //use function from shop to next phone
            shop.StepToNextPhone();
            //display the phone
            DisplayPhone();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            shop = new Shop();
            ImageListForPhone = new ImageList();
            ImageListForSystem = new ImageList();
            shoppingList = new ShoppingList();
            ImageInShoppingList = new ImageList();

            ImageInShoppingList.ImageSize = new Size(100, 115);

            //show "shop name"
            lblShopName.Text = shop.DescribeShopName();

            //add some phone
            ApplePhone applePhone1 = new ApplePhone("IOS", "Apple", "iPhone 6S", MobilePhone.Condition.good, 1600, new DateTime(2015, 4, 24));
            ApplePhone applePhone2 = new ApplePhone("IOS", "Apple", "iPhone X", MobilePhone.Condition.mint, 2000, new DateTime(2017, 2, 24));
            ApplePhone applePhone3 = new ApplePhone("IOS", "Apple", "iPhone 5", MobilePhone.Condition.poor, 1000, new DateTime(2014, 3, 24));
            AndroidPhone androidPhone1 = new AndroidPhone("Android", "Samsumg", "SCH-i699", MobilePhone.Condition.fair, 500, new DateTime(2011, 5, 9));
            AndroidPhone androidPhone2 = new AndroidPhone("Android", "Huawei", "MATE 10", MobilePhone.Condition.poor, 1500, new DateTime(2012, 5, 19));
            AndroidPhone androidPhone3 = new AndroidPhone("Android", "Vivo", "Vivo V7", MobilePhone.Condition.poor, 1500, new DateTime(2013, 8, 19));
            AndroidPhone androidPhone4 = new AndroidPhone("Android", "Vivo", "Vivo X20", MobilePhone.Condition.good, 1500, new DateTime(2017, 1, 19));
            WindowsPhone windowsPhone1 = new WindowsPhone("Windows", "Winphone", "lumia920", MobilePhone.Condition.mint, 1800, new DateTime(2013, 5, 19));
            WindowsPhone windowsPhone2 = new WindowsPhone("Windows", "Winphone", "lumia800", MobilePhone.Condition.mint, 1500, new DateTime(2012, 5, 18));
            WindowsPhone windowsPhone3 = new WindowsPhone("Windows", "Winphone", "lumia900", MobilePhone.Condition.poor, 1000, new DateTime(2013, 4, 18));

            shop.AddPhone(applePhone1);
            shop.AddPhone(applePhone2);
            shop.AddPhone(applePhone3);
            shop.AddPhone(androidPhone1);
            shop.AddPhone(androidPhone2);
            shop.AddPhone(androidPhone3);
            shop.AddPhone(androidPhone4);
            shop.AddPhone(windowsPhone1);
            shop.AddPhone(windowsPhone2);
            shop.AddPhone(windowsPhone3);

            //declare image size and add some phone image
            ImageListForPhone.ImageSize = new Size(195, 254);
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\IPhone6s.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\IPhoneX.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\IPhone5.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\SCH-i699.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\MATE 10.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\VivoV7.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\VivoX20.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\lumia920.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\lumia800.jpg"));
            ImageListForPhone.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\lumia900.jpg"));

            //declare image size and add some operating system image
            ImageListForSystem.ImageSize = new Size(195, 50);
            ImageListForSystem.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\Android.png"));
            ImageListForSystem.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\IOS.png"));
            ImageListForSystem.Images.Add(Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\Windows.png"));

            //display the phone
            DisplayPhone();
        }

        private void DisplayPhone()
        {
            //show the number of cuurrent phone
            lblCurrentPhone.Text = string.Format("Viewing {0} of {1}", shop.CurrentlyViewedPhone + 1, shop.NumberOfPhones);

            //show detail of the cuurrent phone
            txtShowPhoneInfor.Text = shop.DescribeCurrentPhone();
            //set it as read only
            txtShowPhoneInfor.ReadOnly = true;

            //show cuurrent phone image
            pictureForPhone.Image = ImageListForPhone.Images[shop.CurrentlyViewedPhone];
            
            //show shop logo
            pictureForShopName.Image = Image.FromFile("C:\\Users\\Administrator\\Desktop\\AP\\MyPhoneShip\\MyPhoneShip\\Image\\ShopName.png");

            //show operating system image
            //if the phone is Android
            if (shop.DescribeCurrentPhone().Substring(18, 1) == "A")
            {
                //show image for Android
                pictureForSystem.Image = ImageListForSystem.Images[0];
            }
            //if the phone is IOS
            else if (shop.DescribeCurrentPhone().Substring(18, 1) == "I")
            {
                //show image for IOS
                pictureForSystem.Image = ImageListForSystem.Images[1];
            }
            //if not
            else
            {
                //show image for Windows
                pictureForSystem.Image = ImageListForSystem.Images[2];
            }

        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //use function from shop to next phone
            shop.StepToPreviousPhone();
            //display the phone
            DisplayPhone();
        }



        private void txtShowPhoneInfor_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnShoppingList_Click(object sender, EventArgs e)
        {
            //send ImageInShoppingList(imageList) and CountForImageInShoppingList(int) to form2
            Form2 form2 = new Form2(ImageInShoppingList, CountForImageInShoppingList);
            //show form2
            form2.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //the form2 have six picture boxs only, so just can store six elements
            if (shoppingList.GetPhoneInList.Count<6)
            {
                //add phone into shopping car
                shoppingList.AddPhone(shop.GetPhoneStock[shop.CurrentlyViewedPhone]);
                //add image into shopping car
                ImageInShoppingList.Images.Add(ImageListForPhone.Images[shop.CurrentlyViewedPhone]);
                //count it
                CountForImageInShoppingList++;
                //hint: add successful
                MessageBox.Show("Add successful!",":-)");
            }
            else
            {
                //hint: add file
                MessageBox.Show("Add file: Your shopping car was full!","Oops :-(");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Yse/No hint box
            if(MessageBox.Show("Are you sure to exit?", ":-0", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                //bye bye
                this.Close();
            }
        }
    }
}
