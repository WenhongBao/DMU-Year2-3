﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneShop
{
    // mobilePhone is an abstract base class, we inherit car and van from this.
    public abstract class MobilePhone : IComparable
    {
        //the condition for MobilePhone
        public enum Condition
        {
            poor,
            fair,
            good,
            mint
        };

        //declare varible for MobilePhone class
        protected string operatingSystem;
        protected string make;
        protected string model;
        protected Condition condition;
        protected decimal originalPrice;
        protected DateTime dateReleased;

        //constructor
        public MobilePhone(string operatingSystem, string make, string model, Condition condition, decimal originalPrice, DateTime dateReleased)
        {
            this.operatingSystem = operatingSystem;
            this.make = make;
            this.model = model;
            this.condition = condition;
            this.originalPrice = originalPrice;
            this.dateReleased = dateReleased;
        }

        public decimal OriginalPrice()
        {
            return originalPrice;
        }

        public string GetModel()
        {
            return model;
        }

        public DateTime DateReleased()
        {
            return dateReleased;
        }

        public Condition GetCondition()
        {
            return condition;
        }

        public int CalculateApproximateAgeInYears()
        {
            DateTime now = DateTime.Now;
            TimeSpan ageAsTimeSpan = now.Subtract(dateReleased);
            int ageInYears = ageAsTimeSpan.Days / 365;  // doesn't take into account leap years - just approximate
            return ageInYears;
        }



        // this method has to be implemented in the derived class
        public abstract decimal CalculateApproximateValue();

        public virtual string Description()
        {
            // get a string describing the current phone condition from the names in the Condition enumeration
            string conditionName = Enum.GetName(typeof(Condition), condition); // we can get the enumeration name here eg. good or fair as text as opposed to its value

            // build a string describing the current phone
            string description = string.Format("Operating System: {0}{1}Make: {2}{3}Model: {4}{5}Condition: {6}{7}OriginalPrice: {8}{9}Current Value: {10:c}",
                operatingSystem,
                Environment.NewLine,
                make,
                Environment.NewLine,
                model,
                Environment.NewLine,
                condition,
                Environment.NewLine,
                originalPrice,
                Environment.NewLine,
                CalculateApproximateValue());

            return description;
        }

        int IComparable.CompareTo(object obj)
        {
            // iComparable returns   +1, 0 or -1
            MobilePhone otherVehicle = (MobilePhone)obj;
            decimal differenceInPrice = this.CalculateApproximateValue() - otherVehicle.CalculateApproximateValue();
            // we want to return +1, 0 or -1
            return Math.Sign(differenceInPrice);
        }
    }
}
