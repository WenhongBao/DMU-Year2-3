﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPhoneShop
{
    public partial class Form2 : Form
    {
        //a shopping list contains the list of phone in shopping car and a current index
        ShoppingList shoppingList;
        // a shop contains the list of phone and a current index
        Shop shop;
        //create a list to store phone image which in shopping car
        ImageList ImageInShoppingList;
        //create a counter
        int CountForImageInShoppingList;

        public Form2(ImageList imageInShoppingList, int countForImageInShoppingList)
        {
            InitializeComponent();
            //get imageList(from form1)
            ImageInShoppingList = imageInShoppingList;
            //get count number(form form1)
            CountForImageInShoppingList = countForImageInShoppingList;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            shoppingList = new ShoppingList();
            shop = new Shop();

            //show "shopping list"
            lblShoppingList.Text = shoppingList.DescribeShoppingList();
            
            //rest with how many image in list
            //insert image one by one
            if (CountForImageInShoppingList == 1)
            {
                pictureBox1.Image = ImageInShoppingList.Images[0];
            }
            else if(CountForImageInShoppingList == 2)
            {
                pictureBox1.Image = ImageInShoppingList.Images[0];
                pictureBox2.Image = ImageInShoppingList.Images[1];
            }
            else if (CountForImageInShoppingList == 3)
            {
                pictureBox1.Image = ImageInShoppingList.Images[0];
                pictureBox2.Image = ImageInShoppingList.Images[1];
                pictureBox3.Image = ImageInShoppingList.Images[2];
            }
            else if (CountForImageInShoppingList == 4)
            {
                pictureBox1.Image = ImageInShoppingList.Images[0];
                pictureBox2.Image = ImageInShoppingList.Images[1];
                pictureBox3.Image = ImageInShoppingList.Images[2];
                pictureBox4.Image = ImageInShoppingList.Images[3];
            }
            else if (CountForImageInShoppingList == 5)
            {
                pictureBox1.Image = ImageInShoppingList.Images[0];
                pictureBox2.Image = ImageInShoppingList.Images[1];
                pictureBox3.Image = ImageInShoppingList.Images[2];
                pictureBox4.Image = ImageInShoppingList.Images[3];
                pictureBox5.Image = ImageInShoppingList.Images[4];
            }
            else if(CountForImageInShoppingList == 6)
            {
                pictureBox1.Image = ImageInShoppingList.Images[0];
                pictureBox2.Image = ImageInShoppingList.Images[1];
                pictureBox3.Image = ImageInShoppingList.Images[2];
                pictureBox4.Image = ImageInShoppingList.Images[3];
                pictureBox5.Image = ImageInShoppingList.Images[4];
                pictureBox6.Image = ImageInShoppingList.Images[5];
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //rest with how many image in list
            //remove if the current checkbox is checked
            if (CountForImageInShoppingList == 1)
            {
                if (checkBox1.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(0);
                    pictureBox1.Image = null;
                    CountForImageInShoppingList--;
                    checkBox1.Checked = false;
                }
            }
            else if (CountForImageInShoppingList == 2)
            {
                if (checkBox1.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(0);
                    pictureBox1.Image = null;
                    CountForImageInShoppingList--;
                    checkBox1.Checked = false;
                }
                if (checkBox2.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(1);
                    pictureBox2.Image = null;
                    CountForImageInShoppingList--;
                    checkBox2.Checked = false;
                }
            }
            else if (CountForImageInShoppingList == 3)
            {
                if (checkBox1.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(0);
                    pictureBox1.Image = null;
                    CountForImageInShoppingList--;
                    checkBox1.Checked = false;
                }
                if (checkBox2.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(1);
                    pictureBox2.Image = null;
                    CountForImageInShoppingList--;
                    checkBox2.Checked = false;
                }
                if (checkBox3.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(2);
                    pictureBox3.Image = null;
                    CountForImageInShoppingList--;
                    checkBox3.Checked = false;
                }
            }
            else if (CountForImageInShoppingList == 4)
            {
                if (checkBox1.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(0);
                    pictureBox1.Image = null;
                    CountForImageInShoppingList--;
                    checkBox1.Checked = false;
                }
                if (checkBox2.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(1);
                    pictureBox2.Image = null;
                    CountForImageInShoppingList--;
                    checkBox2.Checked = false;
                }
                if (checkBox3.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(2);
                    pictureBox3.Image = null;
                    CountForImageInShoppingList--;
                    checkBox3.Checked = false;
                }
                if (checkBox4.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(3);
                    pictureBox4.Image = null;
                    CountForImageInShoppingList--;
                    checkBox4.Checked = false;
                }
            }
            else if (CountForImageInShoppingList == 5)
            {
                if (checkBox1.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(0);
                    pictureBox1.Image = null;
                    CountForImageInShoppingList--;
                    checkBox1.Checked = false;
                }
                if (checkBox2.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(1);
                    pictureBox2.Image = null;
                    CountForImageInShoppingList--;
                    checkBox2.Checked = false;
                }
                if (checkBox3.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(2);
                    pictureBox3.Image = null;
                    CountForImageInShoppingList--;
                    checkBox3.Checked = false;
                }
                if (checkBox4.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(3);
                    pictureBox4.Image = null;
                    CountForImageInShoppingList--;
                    checkBox4.Checked = false;
                }
                if (checkBox5.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(4);
                    pictureBox5.Image = null;
                    CountForImageInShoppingList--;
                    checkBox5.Checked = false;
                }
            }
            else if (CountForImageInShoppingList == 6)
            {
                if (checkBox1.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(0);
                    pictureBox1.Image = null;
                    CountForImageInShoppingList--;
                    checkBox1.Checked = false;
                }
                if (checkBox2.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(1);
                    pictureBox2.Image = null;
                    CountForImageInShoppingList--;
                    checkBox2.Checked = false;
                }
                if (checkBox3.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(2);
                    pictureBox3.Image = null;
                    CountForImageInShoppingList--;
                    checkBox3.Checked = false;
                }
                if (checkBox4.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(3);
                    pictureBox4.Image = null;
                    CountForImageInShoppingList--;
                    checkBox4.Checked = false;
                }
                if (checkBox5.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(4);
                    pictureBox5.Image = null;
                    CountForImageInShoppingList--;
                    checkBox5.Checked = false;
                }
                if (checkBox6.Checked == true)
                {
                    ImageInShoppingList.Images.RemoveAt(5);
                    pictureBox6.Image = null;
                    CountForImageInShoppingList--;
                    checkBox6.Checked = false;
                }
                Form2_Load(sender, e);
            }
        }

        //only one checkBox can be check in one time

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = true;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = true;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = true;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = true;
                checkBox6.Checked = false;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = true;
            }
        }

        private void btnDeleteAll_Click(object sender, EventArgs e)
        {
            //clear all image in the shopping list
            ImageInShoppingList.Images.Clear();
            pictureBox1.Image = null;
            pictureBox2.Image = null;
            pictureBox3.Image = null;
            pictureBox4.Image = null;
            pictureBox5.Image = null;
            pictureBox6.Image = null;
            CountForImageInShoppingList = 0;
        }
    }
}
